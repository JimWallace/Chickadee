"""
API for Rockstar frontend.




"""
