"""
API for AdaptaHOP frontend.




"""
