// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

#define ARROW_VERSION_MAJOR 22
#define ARROW_VERSION_MINOR 0
#define ARROW_VERSION_PATCH 0
#define ARROW_VERSION ((ARROW_VERSION_MAJOR * 1000) + ARROW_VERSION_MINOR) * 1000 + ARROW_VERSION_PATCH

#define ARROW_VERSION_STRING "22.0.0"

#define ARROW_SO_VERSION "2200"
#define ARROW_FULL_SO_VERSION "2200.0.0"

#define ARROW_CXX_COMPILER_ID "Clang"
#define ARROW_CXX_COMPILER_VERSION "23.0.0"
#define ARROW_CXX_COMPILER_FLAGS " -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/home/siha/.cache/.pyodide-xbuildenv-0.34.3/https_github_com_pyodide_pyodide-build-environment-nightly_releases_download_20260324_314_alpha_xbuildenv_tar_bz2/xbuildenv/pyodide-root/cpython/installs/python-3.14.2/include/python3.14 -Oz -sSUPPORT_LONGJMP='wasm' -Qunused-arguments -fcolor-diagnostics -fPIC -fexceptions -Wno-error=deprecated-literal-operator  -Wall -Wno-unknown-warning-option -Wno-pass-failed "

#define ARROW_BUILD_TYPE "RELEASE"

#define ARROW_PACKAGE_KIND ""

#define ARROW_COMPUTE
#define ARROW_CSV
/* #undef ARROW_CUDA */
#define ARROW_DATASET
#define ARROW_FILESYSTEM
/* #undef ARROW_FLIGHT */
/* #undef ARROW_FLIGHT_SQL */
#define ARROW_IPC
/* #undef ARROW_JEMALLOC */
/* #undef ARROW_JEMALLOC_VENDORED */
#define ARROW_JSON
/* #undef ARROW_MIMALLOC */
#define ARROW_ORC
#define ARROW_PARQUET
#define ARROW_SUBSTRAIT

/* #undef ARROW_AZURE */
/* #undef ARROW_ENABLE_THREADING */
/* #undef ARROW_GCS */
/* #undef ARROW_HDFS */
/* #undef ARROW_S3 */
/* #undef ARROW_USE_GLOG */
#define ARROW_USE_NATIVE_INT128
#define ARROW_WITH_BROTLI
/* #undef ARROW_WITH_BZ2 */
#define ARROW_WITH_LZ4
/* #undef ARROW_WITH_MUSL */
/* #undef ARROW_WITH_OPENTELEMETRY */
#define ARROW_WITH_RE2
#define ARROW_WITH_SNAPPY
#define ARROW_WITH_UTF8PROC
#define ARROW_WITH_ZLIB
#define ARROW_WITH_ZSTD
/* #undef PARQUET_REQUIRE_ENCRYPTION */
