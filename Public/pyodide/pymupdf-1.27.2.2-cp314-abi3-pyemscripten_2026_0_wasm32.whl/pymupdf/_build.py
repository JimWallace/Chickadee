mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.27.2-source.tar.gz'
pymupdf_version = '1.27.2.2'
pymupdf_version_tuple = (1, 27, 2, 2)
pymupdf_git_sha = '8b831e735118ba6707ee830777b2646900734954'
pymupdf_git_diff = ''
pymupdf_git_branch = 'HEAD'
swig_version = '4.4.1'
swig_version_tuple = (4, 4, 1)
