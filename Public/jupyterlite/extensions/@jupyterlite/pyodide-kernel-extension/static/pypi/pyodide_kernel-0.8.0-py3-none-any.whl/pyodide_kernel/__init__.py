"""A Python kernel backed by Pyodide"""

__version__ = "0.8.0"

import sys

# 0. do early mocks that change `sys.modules`
from . import mocks

mocks.apply_mocks()
del mocks

# 1. do expensive patches that require imports
from . import patches

patches.apply_patches()
del patches

# 2. set up the rest of the IPython-like environment
from .display import LiteStream
from .interpreter import LitePythonShellApp

stdout_stream = LiteStream("stdout")
stderr_stream = LiteStream("stderr")

ipython_shell_app = LitePythonShellApp()
ipython_shell_app.initialize()
ipython_shell = ipython_shell_app.shell
kernel_instance = ipython_shell.kernel

# 3. handle streams
sys.stdout = stdout_stream
sys.stderr = stderr_stream


# --- CHICKADEE_NB_MYPY_ACTIVATION -----------------------------------------------------------
# exec_hang FIX (synchronous — must run at kernel import, before the first cell
# execute). The JupyterLite notebook frontend sets the kernel's working directory
# to the notebook's Drive folder by running os.chdir("users/<uid>/<setup>/") on
# the first execute. That folder only exists in the kernel's Pyodide filesystem
# if the DriveFS is mounted, which needs the service worker we disable to run
# SAB-only under cross-origin isolation (SecurityHeadersMiddleware / #989/#1003).
# With no service worker the folder is absent, so chdir raises FileNotFoundError;
# that error is unhandled inside Pyodide's WebLoop, so the execute coroutine never
# completes and the cell wedges "[*]"-forever — the production exec_hang (~1 in 4
# students; 100% in the headless repro; students carrying a stale SW registration
# have a working DriveFS and never hit it, which is exactly the partial rate).
#
# Fix: make chdir create the target directory first. SAFE + TARGETED — when the
# DriveFS already provides the folder (the working majority) makedirs is a no-op
# and behaviour is unchanged; when it is missing the kernel runs in a (possibly
# empty) folder instead of hanging. (Support files the DriveFS would surface into
# that folder are a separate follow-up; a working kernel strictly beats a hung
# one.) Verified: 100% headless hang -> 0% with this patch.
try:  # pragma: no cover - exercised only in the in-browser kernel
    import os as _chickadee_os

    _chickadee_orig_chdir = _chickadee_os.chdir

    def _chickadee_chdir(path):
        try:
            _chickadee_os.makedirs(path, exist_ok=True)
        except Exception:  # noqa: BLE001
            pass
        return _chickadee_orig_chdir(path)

    _chickadee_os.chdir = _chickadee_chdir
except Exception:  # noqa: BLE001
    pass

# nb_mypy type-checking is DISABLED — intentionally NO code is injected here.
# It registered an IPython pre_run_cell hook that ran a synchronous compiled-WASM
# mypy on EVERY cell execute (on the kernel's single thread) and wedged the first
# cell; see the module docstring. The markers are kept so re-enabling is a
# one-line change and the sha cascade below is unchanged. The nb_mypy / mypy /
# astor wheels stay vended (harmless, just unloaded).
# --- end CHICKADEE_NB_MYPY_ACTIVATION -------------------------------------------------------
