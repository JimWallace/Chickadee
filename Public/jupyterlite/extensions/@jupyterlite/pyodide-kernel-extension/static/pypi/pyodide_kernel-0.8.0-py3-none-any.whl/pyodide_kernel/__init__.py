"""A Python kernel backed by Pyodide"""

__version__ = "0.8.0"

import sys

# 0. do early mocks that change `sys.modules`
from . import mocks

mocks.apply_mocks()
del mocks

# 1. do expensive patches that require imports
from . import patches

patches.apply_patches()
del patches

# 2. set up the rest of the IPython-like environment
from .display import LiteStream
from .interpreter import LitePythonShellApp

stdout_stream = LiteStream("stdout")
stderr_stream = LiteStream("stderr")

ipython_shell_app = LitePythonShellApp()
ipython_shell_app.initialize()
ipython_shell = ipython_shell_app.shell
kernel_instance = ipython_shell.kernel

# 3. handle streams
sys.stdout = stdout_stream
sys.stderr = stderr_stream


# --- CHICKADEE_NB_MYPY_ACTIVATION -----------------------------------------------------------
# nb_mypy type-checking is DISABLED — deliberately injects NO code.
#
# nb_mypy registered an IPython `pre_run_cell` hook that ran a full, synchronous,
# compiled-WASM `mypy.api.run(...)` before EVERY cell, on the kernel's single
# thread. In the real notebook editor the first cell execute wedged the kernel
# ("[*]" forever — the exec_hang ~1 in 4 students hit on lab day). It reproduced
# deterministically in CI (Tools/editor-smoke-test/editor-exec-check.mjs): on
# both Chromium and WebKit, the first editor-cell execute hung 5/5 whether run
# immediately at idle OR after a 45s settle — so deferring the background load
# does not help, the per-cell mypy run itself is the cost. In the race case the
# background load colliding with the execute could even fatally crash Pyodide
# ("JSON Parse error: Unterminated string").
#
# So the activation is removed. The nb_mypy / mypy / astor wheels stay vended in
# the Pyodide lock (harmless, just unloaded) so this is a one-line revert if a
# non-blocking design lands. Revisit type-checking as a background-worker /
# language-server feature that NEVER runs on the cell-execute path.
# --- end CHICKADEE_NB_MYPY_ACTIVATION -------------------------------------------------------
