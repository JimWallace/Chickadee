"""A Python kernel backed by Pyodide"""

__version__ = "0.7.2"

import sys

# 0. do early mocks that change `sys.modules`
from . import mocks

mocks.apply_mocks()
del mocks

# 1. do expensive patches that require imports
from . import patches

patches.apply_patches()
del patches

# 2. set up the rest of the IPython-like environment
from .display import LiteStream
from .interpreter import LitePythonShellApp

stdout_stream = LiteStream("stdout")
stderr_stream = LiteStream("stderr")

ipython_shell_app = LitePythonShellApp()
ipython_shell_app.initialize()
ipython_shell = ipython_shell_app.shell
kernel_instance = ipython_shell.kernel

# 3. handle streams
sys.stdout = stdout_stream
sys.stderr = stderr_stream


# --- CHICKADEE_NB_MYPY_ACTIVATION -----------------------------------------------------------
# Enable nb_mypy type-checking for the in-browser editor — LAZILY, off the
# kernel-boot critical path. nb_mypy (+ mypy, astor) lives in the vended Pyodide
# lock but is deliberately NOT in loadPyodideOptions.packages: loading it there
# would tie kernel boot to nb_mypy, so any load failure would brick the whole
# editor. Instead we schedule a background task that loads it AFTER the kernel
# is up, then turns type-checking on. Fail-safe: any failure (missing or
# incompatible wheel, bad lock key, scheduling error) degrades to "no type
# warnings" — the kernel stays healthy and usable.
try:  # pragma: no cover - exercised only in the in-browser kernel
    import asyncio as _chickadee_asyncio

    async def _chickadee_enable_nb_mypy():
        try:
            import pyodide_js as _chickadee_pyodide_js

            await _chickadee_pyodide_js.loadPackage("nb-mypy")
            ipython_shell.run_line_magic("load_ext", "nb_mypy")
            ipython_shell.run_line_magic("nb_mypy", "On")
        except Exception as _chickadee_nbmypy_err:  # noqa: BLE001
            import warnings as _chickadee_warnings

            _chickadee_warnings.warn(
                f"Chickadee: nb_mypy type-checking not enabled: {_chickadee_nbmypy_err!r}"
            )

    _chickadee_asyncio.ensure_future(_chickadee_enable_nb_mypy())
except Exception as _chickadee_nbmypy_sched_err:  # noqa: BLE001
    import warnings as _chickadee_warnings

    _chickadee_warnings.warn(
        f"Chickadee: nb_mypy activation could not be scheduled: {_chickadee_nbmypy_sched_err!r}"
    )
# --- end CHICKADEE_NB_MYPY_ACTIVATION -------------------------------------------------------
