"""A Python kernel backed by Pyodide"""

__version__ = "0.7.2"

import sys

# 0. do early mocks that change `sys.modules`
from . import mocks

mocks.apply_mocks()
del mocks

# 1. do expensive patches that require imports
from . import patches

patches.apply_patches()
del patches

# 2. set up the rest of the IPython-like environment
from .display import LiteStream
from .interpreter import LitePythonShellApp

stdout_stream = LiteStream("stdout")
stderr_stream = LiteStream("stderr")

ipython_shell_app = LitePythonShellApp()
ipython_shell_app.initialize()
ipython_shell = ipython_shell_app.shell
kernel_instance = ipython_shell.kernel

# 3. handle streams
sys.stdout = stdout_stream
sys.stderr = stderr_stream


# --- CHICKADEE_NB_MYPY_ACTIVATION -----------------------------------------------------------
# Enable nb_mypy type-checking by default for the in-browser editor. nb_mypy
# (+ mypy, astor) is preloaded via loadPyodideOptions in jupyter-lite.json.
# Fail-safe: NEVER let type-checking setup stop the kernel from starting.
try:  # pragma: no cover - exercised only in the in-browser kernel
    ipython_shell.run_line_magic("load_ext", "nb_mypy")
    ipython_shell.run_line_magic("nb_mypy", "On")
except Exception as _chickadee_nbmypy_err:  # noqa: BLE001
    import warnings as _chickadee_warnings

    _chickadee_warnings.warn(
        f"Chickadee: nb_mypy type-checking not enabled: {_chickadee_nbmypy_err!r}"
    )
# --- end CHICKADEE_NB_MYPY_ACTIVATION -------------------------------------------------------
