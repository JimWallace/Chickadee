############################################################################
# Copyright (c) 2022, Giulio Girardi
#
#
# Distributed under the terms of the GNU General Public License v3.
#
# The full license is in the file LICENSE, distributed with this software.
############################################################################

# xeus-octave cmake module
# This module sets the following variables in your project::
#
#   xeus-octave_FOUND - true if xeus-octave was found on the system
#   xeus-octave_INCLUDE_DIRS - the directory containing xeus-octave headers
#   xeus-octave_LIBRARY - the library for dynamic linking
#   xeus-octave_STATIC_LIBRARY - the library for static linking


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was xeus-octaveConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR};${CMAKE_MODULE_PATH}")



include(CMakeFindDependencyMacro)
find_dependency(xeus-zmq )
find_dependency(PkgConfig REQUIRED)
pkg_check_modules(octinterp REQUIRED IMPORTED_TARGET GLOBAL octinterp=10.3.0)

if (NOT TARGET xeus-octave AND NOT TARGET xeus-octave-static)
    include("${CMAKE_CURRENT_LIST_DIR}/xeus-octaveTargets.cmake")

    if (TARGET xeus-octave AND TARGET xeus-octave-static)
        get_target_property(xeus-octave_INCLUDE_DIR xeus-octave INTERFACE_INCLUDE_DIRECTORIES)
        get_target_property(xeus-octave_LIBRARY xeus-octave LOCATION)
        get_target_property(xeus-octave_STATIC_LIBRARY xeus-octave-static LOCATION)
    elseif (TARGET xeus-octave)
        get_target_property(xeus-octave_INCLUDE_DIR xeus-octave INTERFACE_INCLUDE_DIRECTORIES)
        get_target_property(xeus-octave_LIBRARY xeus-octave LOCATION)
    elseif (TARGET xeus-octave-static)
        get_target_property(xeus-octave_INCLUDE_DIR xeus-octave-static INTERFACE_INCLUDE_DIRECTORIES)
        get_target_property(xeus-octave_STATIC_LIBRARY xeus-octave-static LOCATION)
        set(xeus-octave_LIBRARY ${xeus-octave_STATIC_LIBRARY})
    endif ()
endif ()
