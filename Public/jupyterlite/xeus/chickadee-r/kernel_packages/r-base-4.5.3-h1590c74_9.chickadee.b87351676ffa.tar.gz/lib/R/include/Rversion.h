/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 263427
#define R_NICK "Reassured Reassurer"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "4"
#define R_MINOR  "5.3"
#define R_STATUS ""
#define R_YEAR   "2026"
#define R_MONTH  "03"
#define R_DAY    "11"
#define R_SVN_REVISION 89597
#ifdef __llvm__
# define R_FILEVERSION    4,53,24061,0
#else
# define R_FILEVERSION    4,53,89597,0
#endif

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
