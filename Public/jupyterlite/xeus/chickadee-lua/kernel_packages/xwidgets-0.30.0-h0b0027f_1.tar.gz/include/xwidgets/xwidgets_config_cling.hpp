/***************************************************************************
 * Copyright (c) 2017, Sylvain Corlay and Johan Mabille                     *
 *                                                                          *
 * Distributed under the terms of the BSD 3-Clause License.                 *
 *                                                                          *
 * The full license is in the file LICENSE, distributed with this software. *
 ****************************************************************************/

#ifndef XWIDGETS_CONFIG_CLING_HPP
#define XWIDGETS_CONFIG_CLING_HPP

#ifdef __CLING__

#pragma cling add_library_path("/tmp/tmpocyy_o0b/_env/envs/chickadee-lua/lib")
#pragma cling load("libxwidgets")

#endif  // __CLING__

#ifdef __CLANG_REPL__

#if defined(__has_include)
// Newer CppInterop>=1.8.0
#if __has_include("CppInterOp/CppInterOp.h")
#include <CppInterOp/CppInterOp.h>
// Older
#else
#include <clang/Interpreter/CppInterOp.h>
#endif
#endif  // __has_include

static bool _xwidgets_loaded = []()
{
    Cpp::LoadLibrary(
#ifdef __EMSCRIPTEN__
        "/lib/libxwidgets.so"
#else
        "libxwidgets"
#endif
    );
    return true;
}();

#endif  // __CLANG_REPL__

#endif  // XWIDGETS_CONFIG_CLING_HPP
