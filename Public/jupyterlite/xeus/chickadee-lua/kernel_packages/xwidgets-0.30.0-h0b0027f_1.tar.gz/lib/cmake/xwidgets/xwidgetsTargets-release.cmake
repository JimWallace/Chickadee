#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xwidgets-static" for configuration "Release"
set_property(TARGET xwidgets-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xwidgets-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libxwidgets.a"
  )

list(APPEND _cmake_import_check_targets xwidgets-static )
list(APPEND _cmake_import_check_files_for_xwidgets-static "${_IMPORT_PREFIX}/lib/libxwidgets.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
